-- Quips Forever: the in-game bar.
local _, ns = ...

local BAR_WIDTH = 450
local ROW_H = 18
local MIN_ROWS, MAX_ROWS, DEFAULT_ROWS = 3, 30, 10
local BOTTOM_PAD = 16
local numRows = DEFAULT_ROWS
local sizing = false
local STRIP_H = 34
local DEFAULT_POS = { "TOPLEFT", "TOPLEFT", 20, -110 }

local bar, scroll, rows, emptyText
local channelBtn, catBtn, searchBox, collapseBtn, sizer

local function HeightFor(n) return STRIP_H + n * ROW_H + BOTTOM_PAD end
local function RowsForHeight(h)
    local n = math.floor((h - STRIP_H - BOTTOM_PAD) / ROW_H + 0.5)
    return math.max(MIN_ROWS, math.min(MAX_ROWS, n))
end
local filtered = {}

------------------------------------------------------------------------
-- Position, lock, visibility
------------------------------------------------------------------------

local function ApplyPosition()
    local p = ns.charDB.position or DEFAULT_POS
    bar:ClearAllPoints()
    bar:SetPoint(p[1], UIParent, p[2], p[3], p[4])
end

local function SavePosition()
    local point, _, relPoint, x, y = bar:GetPoint(1)
    ns.charDB.position = { point, relPoint, x, y }
end

function ns.ResetBarPosition()
    ns.charDB.position = nil
    if bar then
        ApplyPosition()
        ns.settings.hidden = false
        bar:Show()
    end
    ns.Print("Bar moved back to its default spot.")
end

function ns.SetLocked(locked)
    ns.settings.locked = locked and true or false
    ns.Print(locked and "Bar locked." or "Bar unlocked. Drag the grip on the left to move it.")
end

function ns.ToggleBar()
    if not bar then return end
    if bar:IsShown() then
        bar:Hide()
        ns.settings.hidden = true
    else
        bar:Show()
        ns.settings.hidden = false
    end
end

------------------------------------------------------------------------
-- Building blocks
------------------------------------------------------------------------

local function ChannelLabel(key)
    for _, c in ipairs(ns.CHANNELS) do
        if c.key == key then return c.label end
    end
    return "Say"
end

local function MakeDropButton(parent, width)
    local b = ns.CreateBackdropFrame("Button", nil, parent)
    b:SetSize(width, 22)
    if b.SetBackdropColor then b:SetBackdropColor(0.15, 0.15, 0.15, 1) end
    b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    b.text:SetPoint("LEFT", 7, 0)
    b.text:SetPoint("RIGHT", -18, 0)
    b.text:SetJustifyH("LEFT")
    b.text:SetWordWrap(false)
    local arrow = b:CreateTexture(nil, "ARTWORK")
    arrow:SetTexture("Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up")
    arrow:SetSize(16, 16)
    arrow:SetPoint("RIGHT", -2, 0)
    return b
end

local function MakeIconButton(parent, texture, size)
    local b = CreateFrame("Button", nil, parent)
    b:SetSize(size, size)
    b:SetNormalTexture(texture)
    b:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
    b:SetPushedTexture(texture)
    local pushed = b:GetPushedTexture()
    if pushed then pushed:SetVertexColor(0.7, 0.7, 0.7) end
    return b
end

local function ScrollBy(delta)
    local sb = scroll.ScrollBar or _G[scroll:GetName() .. "ScrollBar"]
    if sb and sb:IsShown() then
        sb:SetValue(sb:GetValue() - delta * ROW_H * 3)
    end
end

------------------------------------------------------------------------
-- Menus
------------------------------------------------------------------------

local function ShowChannelMenu()
    local items = {}
    for _, c in ipairs(ns.CHANNELS) do
        items[#items + 1] = {
            text = c.label,
            checked = ns.settings.channel == c.key,
            func = function() ns.settings.channel = c.key; ns.RefreshBar() end,
        }
    end
    ns.ToggleMenu(channelBtn, items)
end

local function ShowCategoryMenu()
    local items = {}
    for _, c in ipairs(ns.Categories()) do
        items[#items + 1] = {
            text = ("%s  (%d)"):format(c.name, #c.phrases),
            checked = ns.settings.category == c.name,
            func = function()
                ns.settings.category = c.name
                ns.settings.collapsed = false
                searchBox:SetText("")
                ns.RefreshBar()
            end,
        }
    end
    if #items == 0 then
        items[1] = { text = "No categories yet. Open the editor.", func = function() ns.ShowAdmin() end }
    end
    ns.ToggleMenu(catBtn, items)
end

local function ShowBarMenu(owner)
    ns.ToggleMenu(owner, {
        { text = ns.settings.locked and "Unlock bar" or "Lock bar",
          func = function() ns.SetLocked(not ns.settings.locked) end },
        { text = "Reset position", func = function() ns.ResetBarPosition() end },
        { text = "Open phrasebook editor", func = function() ns.ShowAdmin() end },
        { text = "Hide bar (/quips to show)", func = function() ns.ToggleBar() end },
    })
end

------------------------------------------------------------------------
-- Rows
------------------------------------------------------------------------

local function RowTooltip(self)
    if not self.phrase then return nil end
    local text, err = ns.Prepare(self.phrase)
    return "Send to " .. ChannelLabel(ns.settings.channel), text or err
end

local function UpdateRows()
    local cat = ns.CurrentCategory()
    wipe(filtered)
    if cat then
        local q = ns.Trim(searchBox:GetText()):lower()
        for _, p in ipairs(cat.phrases) do
            if q == "" or p:lower():find(q, 1, true) then
                filtered[#filtered + 1] = p
            end
        end
    end

    FauxScrollFrame_Update(scroll, #filtered, numRows, ROW_H)
    local offset = FauxScrollFrame_GetOffset(scroll)
    for i = 1, MAX_ROWS do
        local row = rows[i]
        local phrase = i <= numRows and filtered[offset + i]
        if phrase then
            row.phrase = phrase
            row.text:SetText(phrase)
            row:Show()
        else
            row.phrase = nil
            row:Hide()
        end
    end

    if not cat then
        emptyText:SetText("No categories yet. Click the gear to add some.")
    elseif #cat.phrases == 0 then
        emptyText:SetText("No phrases in this category. Click the gear to add some.")
    elseif #filtered == 0 then
        emptyText:SetText("No phrases match your search.")
    else
        emptyText:SetText("")
    end
end

local function MakeRow(i)
    local row = CreateFrame("Button", nil, bar)
    row:SetHeight(ROW_H)
    row:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, -(i - 1) * ROW_H)
    row:SetPoint("RIGHT", scroll, "RIGHT", 0, 0)
    row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
    row:RegisterForClicks("LeftButtonUp")

    local say = ns.MakeButton(row, "Say", 40, 17)
    say:SetPoint("RIGHT", -2, 0)
    say:SetNormalFontObject(GameFontNormalSmall)
    say:SetHighlightFontObject(GameFontHighlightSmall)
    row.say = say

    row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    row.text:SetPoint("LEFT", 4, 0)
    row.text:SetPoint("RIGHT", say, "LEFT", -6, 0)
    row.text:SetJustifyH("LEFT")
    row.text:SetWordWrap(false)

    local function Send()
        if not row.phrase then return end
        ns.Send(row.phrase)
        GameTooltip:Hide()
        ns.settings.collapsed = true
        ns.RefreshBar()
    end
    row:SetScript("OnClick", Send)
    say:SetScript("OnClick", Send)
    ns.AttachTooltip(row, RowTooltip)
    ns.AttachTooltip(say, function() return RowTooltip(row) end)

    row:EnableMouseWheel(true)
    row:SetScript("OnMouseWheel", function(_, d) ScrollBy(d) end)
    return row
end

------------------------------------------------------------------------
-- Refresh
------------------------------------------------------------------------

function ns.RefreshBar()
    if not bar then return end
    channelBtn.text:SetText(ChannelLabel(ns.settings.channel))
    local cat = ns.CurrentCategory()
    catBtn.text:SetText(cat and cat.name or "(none)")

    local collapsed = ns.settings.collapsed
    collapseBtn:SetNormalTexture(collapsed and "Interface\\Buttons\\UI-PlusButton-Up" or "Interface\\Buttons\\UI-MinusButton-Up")
    collapseBtn:SetPushedTexture(collapsed and "Interface\\Buttons\\UI-PlusButton-Down" or "Interface\\Buttons\\UI-MinusButton-Down")
    if collapsed then
        scroll:Hide()
        for _, r in ipairs(rows) do r:Hide() end
        emptyText:Hide()
        sizer:Hide()
        bar:SetHeight(STRIP_H + 4)
    else
        scroll:Show()
        emptyText:Show()
        sizer:Show()
        if not sizing then bar:SetHeight(HeightFor(numRows)) end
        UpdateRows()
    end
end

------------------------------------------------------------------------
-- Create
------------------------------------------------------------------------

function ns.CreateBar()
    if bar then return end
    bar = ns.CreateBackdropFrame("Frame", "QuipsForeverBar", UIParent)
    bar:SetWidth(BAR_WIDTH)
    bar:SetFrameStrata("MEDIUM")
    bar:SetClampedToScreen(true)
    bar:SetMovable(true)
    bar:EnableMouse(true)
    bar:RegisterForDrag("LeftButton")
    bar:SetScript("OnDragStart", function(self)
        if not ns.settings.locked then self:StartMoving() end
    end)
    bar:SetScript("OnDragStop", function(self)
        self:StopMovingOrSizing()
        SavePosition()
    end)
    bar:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" then ShowBarMenu(self) end
    end)
    bar:SetScript("OnHide", function() ns.HideMenu() end)

    -- Title strip above the bar: black with yellow text. Drag to move, right-click for options.
    local TITLE_H = 16
    local titleBar = CreateFrame("Frame", nil, bar)
    titleBar:SetPoint("BOTTOMLEFT", bar, "TOPLEFT", 0, -1)
    titleBar:SetPoint("BOTTOMRIGHT", bar, "TOPRIGHT", 0, -1)
    titleBar:SetHeight(TITLE_H)
    titleBar:EnableMouse(true)
    titleBar:RegisterForDrag("LeftButton")
    local tbg = titleBar:CreateTexture(nil, "BACKGROUND")
    tbg:SetAllPoints()
    tbg:SetTexture("Interface\\Buttons\\WHITE8X8")
    tbg:SetVertexColor(0, 0, 0, 1)
    local ttext = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    ttext:SetPoint("CENTER", 0, 0)
    ttext:SetTextColor(1, 0.82, 0)
    ttext:SetText("Quips Forever")
    titleBar:SetScript("OnDragStart", function() if not ns.settings.locked then bar:StartMoving() end end)
    titleBar:SetScript("OnDragStop", function() bar:StopMovingOrSizing(); SavePosition() end)
    titleBar:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" then ShowBarMenu(self) end
    end)
    -- keep the title strip on screen too
    bar:SetClampRectInsets(0, 0, TITLE_H, 0)

    -- Grip on the left edge: drag to move, right-click for options
    local grip = CreateFrame("Frame", nil, bar)
    grip:SetPoint("TOPLEFT", 5, -6)
    grip:SetSize(10, 22)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    local gtex = grip:CreateTexture(nil, "ARTWORK")
    gtex:SetAllPoints()
    gtex:SetTexture("Interface\\Buttons\\WHITE8X8")
    gtex:SetVertexColor(0.5, 0.5, 0.5, 0.35)
    grip:SetScript("OnDragStart", function() if not ns.settings.locked then bar:StartMoving() end end)
    grip:SetScript("OnDragStop", function() bar:StopMovingOrSizing(); SavePosition() end)
    grip:SetScript("OnMouseUp", function(self, button)
        if button == "RightButton" then ShowBarMenu(self) end
    end)
    ns.AttachTooltip(grip, function()
        return "Quips Forever", "Drag to move. Right-click for options."
    end)

    channelBtn = MakeDropButton(bar, 70)
    channelBtn:SetPoint("TOPLEFT", 20, -6)
    channelBtn:SetScript("OnClick", ShowChannelMenu)
    ns.AttachTooltip(channelBtn, function() return "Channel", "Where your phrases are sent." end)

    catBtn = MakeDropButton(bar, 160)
    catBtn:SetPoint("LEFT", channelBtn, "RIGHT", 4, 0)
    catBtn:SetScript("OnClick", ShowCategoryMenu)
    ns.AttachTooltip(catBtn, function()
        local c = ns.CurrentCategory()
        if not c then return "Category", "No categories yet." end
        return c.name, c.description
    end)

    local dice = MakeIconButton(bar, "Interface\\Buttons\\UI-GroupLoot-Dice-Up", 22)
    dice:SetPoint("LEFT", catBtn, "RIGHT", 4, 0)
    dice:SetScript("OnClick", function() ns.SendRandom() end)
    ns.AttachTooltip(dice, function()
        return "Random", "Sends a random phrase from this category. Every phrase comes up once before any repeats."
    end)

    searchBox = ns.MakeEditBox(bar, 102)
    searchBox:SetPoint("LEFT", dice, "RIGHT", 10, 0)
    local hint = searchBox:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("LEFT", 2, 0)
    hint:SetText("Search")
    searchBox:SetTextInsets(0, 14, 0, 0)
    local clear = CreateFrame("Button", nil, searchBox)
    clear:SetSize(14, 14)
    clear:SetPoint("RIGHT", searchBox, "RIGHT", -2, 0)
    local cx = clear:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    cx:SetPoint("CENTER", 0, 1)
    cx:SetText("x")
    cx:SetTextColor(0.7, 0.7, 0.7)
    clear:SetScript("OnEnter", function() cx:SetTextColor(1, 0.82, 0) end)
    clear:SetScript("OnLeave", function() cx:SetTextColor(0.7, 0.7, 0.7) end)
    clear:SetScript("OnClick", function()
        searchBox:SetText("")
        searchBox:ClearFocus()
    end)
    clear:Hide()
    searchBox:SetScript("OnTextChanged", function(self)
        hint:SetShown(self:GetText() == "" and not self:HasFocus())
        clear:SetShown(self:GetText() ~= "")
        if not ns.settings.collapsed then
            if FauxScrollFrame_SetOffset then FauxScrollFrame_SetOffset(scroll, 0) end
            local sb = scroll.ScrollBar or _G[scroll:GetName() .. "ScrollBar"]
            if sb then sb:SetValue(0) end
            UpdateRows()
        end
    end)
    searchBox:SetScript("OnEditFocusGained", function() hint:Hide() end)
    searchBox:SetScript("OnEditFocusLost", function(self) hint:SetShown(self:GetText() == "") end)

    local gear = MakeIconButton(bar, "Interface\\Icons\\INV_Misc_Gear_01", 22)
    gear:SetPoint("LEFT", searchBox, "RIGHT", 6, 0)
    gear:SetScript("OnClick", function() ns.ShowAdmin() end)
    ns.AttachTooltip(gear, function() return "Phrasebook editor", "Add, edit and reorder categories and phrases." end)

    collapseBtn = CreateFrame("Button", nil, bar)
    collapseBtn:SetSize(18, 18)
    collapseBtn:SetPoint("LEFT", gear, "RIGHT", 6, 0)
    collapseBtn:SetHighlightTexture("Interface\\Buttons\\UI-PlusButton-Hilight", "ADD")
    collapseBtn:SetScript("OnClick", function()
        ns.settings.collapsed = not ns.settings.collapsed
        ns.RefreshBar()
    end)
    ns.AttachTooltip(collapseBtn, function()
        return ns.settings.collapsed and "Show phrase list" or "Hide phrase list"
    end)

    scroll = CreateFrame("ScrollFrame", "QuipsForeverBarScroll", bar, "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -STRIP_H)
    scroll:SetPoint("BOTTOMRIGHT", -30, BOTTOM_PAD)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, ROW_H, UpdateRows)
    end)

    rows = {}
    for i = 1, MAX_ROWS do rows[i] = MakeRow(i) end

    -- Vertical resizing: drag the grabber in the bottom-right corner
    numRows = ns.charDB.rows and RowsForHeight(HeightFor(ns.charDB.rows)) or DEFAULT_ROWS
    bar:SetResizable(true)
    if bar.SetResizeBounds then
        bar:SetResizeBounds(BAR_WIDTH, HeightFor(MIN_ROWS), BAR_WIDTH, HeightFor(MAX_ROWS))
    elseif bar.SetMinResize then
        bar:SetMinResize(BAR_WIDTH, HeightFor(MIN_ROWS))
        bar:SetMaxResize(BAR_WIDTH, HeightFor(MAX_ROWS))
    end
    sizer = CreateFrame("Button", nil, bar)
    sizer:SetSize(14, 14)
    sizer:SetPoint("BOTTOMRIGHT", -3, 3)
    sizer:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    sizer:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    sizer:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    sizer:SetScript("OnMouseDown", function(_, button)
        if button == "LeftButton" and not ns.settings.locked then
            sizing = true
            bar:StartSizing("BOTTOM")
        end
    end)
    sizer:SetScript("OnMouseUp", function()
        if not sizing then return end
        sizing = false
        bar:StopMovingOrSizing()
        numRows = RowsForHeight(bar:GetHeight())
        ns.charDB.rows = numRows
        SavePosition()
        ns.RefreshBar()
    end)
    ns.AttachTooltip(sizer, function() return "Resize", "Drag up or down to show more or fewer phrases." end)
    bar:SetScript("OnSizeChanged", function(self, w, h)
        if sizing then
            local n = RowsForHeight(h)
            if n ~= numRows then numRows = n; UpdateRows() end
        end
    end)

    emptyText = bar:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    emptyText:SetPoint("TOPLEFT", scroll, "TOPLEFT", 6, -6)
    emptyText:SetPoint("RIGHT", scroll, "RIGHT", -6, 0)
    emptyText:SetJustifyH("LEFT")

    ApplyPosition()
    ns.RefreshBar()
    if ns.settings.hidden then bar:Hide() else bar:Show() end
end
