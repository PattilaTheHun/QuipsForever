-- Quips Forever: sample categories, created on first run only.
local _, ns = ...

ns.DEFAULT_CATEGORIES = {
    {
        name = "Greetings",
        description = "Friendly hellos for folks you meet on the road",
        phrases = {
            "Well met, %t!",
            "Safe travels, %t. Mind the wildlife in %z.",
            "Hail, friend! Good hunting out there.",
            "Greetings from a humble %r %c. Need a hand with anything?",
            "Fair winds and full bags to you, %t.",
        },
    },
    {
        name = "Dungeon Etiquette",
        description = "Things to say at the start of a dungeon run",
        phrases = {
            "Hey all, %n here. Happy to tank, just call out if I pull too fast.",
            "Need before greed, and roll on what you can use. Let's have fun.",
            "Quick drink break before the next pull, please.",
            "Nice run, everyone. Thanks for the group!",
        },
    },
    {
        name = "Campfire Jokes",
        description = "Funny WoW-themed jokes to say out loud around a campfire",
        phrases = {
            "You know what this fire needs? One guy with a guitar who only knows the first 20 seconds of Wonderwall.",
            "Every campfire eventually reaches the point where somebody starts talking about cryptocurrency.",
            "I asked a murloc for directions once. Still not sure if I was supposed to go left or mrglglgl.",
            "My hearthstone has an hour cooldown and I still manage to use it right before the good part of every story.",
            "Some people collect mounts. I collect gray items I am absolutely going to sell later.",
        },
    },
}
