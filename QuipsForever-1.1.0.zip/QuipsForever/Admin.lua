-- Quips Forever: admin window (categories, phrases) and the phrase editor.
local _, ns = ...

local CAT_ROW_H, CAT_ROWS = 30, 9
local PH_ROW_H, PH_ROWS = 20, 10

local admin, catScroll, catRows, phScroll, phRows
local nameBox, descBox, catStatus
local catButtons, phButtons = {}, {}
local selCat, selPhrase = 1, nil
local loadedCat

local editor

------------------------------------------------------------------------
-- Helpers
------------------------------------------------------------------------

local function Cats() return ns.Categories() end

local function SelectedCategory()
    return Cats()[selCat]
end

local function SetCatStatus(msg, isError)
    catStatus:SetText(msg or "")
    if isError then catStatus:SetTextColor(1, 0.3, 0.3) else catStatus:SetTextColor(0.5, 1, 0.5) end
end

local function Swap(t, i, j)
    t[i], t[j] = t[j], t[i]
end

local function ScrollBarOf(sf)
    return sf.ScrollBar or _G[sf:GetName() .. "ScrollBar"]
end

local function MakeList(parent, name, x, y, width, rowH, numRows, makeRow, update)
    local sf = CreateFrame("ScrollFrame", name, parent, "FauxScrollFrameTemplate")
    sf:SetPoint("TOPLEFT", x, y)
    sf:SetSize(width, rowH * numRows)
    sf:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, rowH, update)
    end)
    local bg = ns.CreateBackdropFrame("Frame", nil, parent)
    bg:SetPoint("TOPLEFT", sf, "TOPLEFT", -5, 5)
    bg:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", 27, -5)
    bg:SetFrameLevel(math.max(0, sf:GetFrameLevel() - 1))
    local list = {}
    for i = 1, numRows do
        local row = CreateFrame("Button", nil, parent)
        row:SetHeight(rowH)
        row:SetPoint("TOPLEFT", sf, "TOPLEFT", 0, -(i - 1) * rowH)
        row:SetPoint("RIGHT", sf, "RIGHT", 0, 0)
        row:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
        row.sel = row:CreateTexture(nil, "BACKGROUND")
        row.sel:SetAllPoints()
        row.sel:SetTexture("Interface\\Buttons\\WHITE8X8")
        row.sel:SetVertexColor(1, 0.82, 0, 0.25)
        row.sel:Hide()
        row:EnableMouseWheel(true)
        row:SetScript("OnMouseWheel", function(_, d)
            local sb = ScrollBarOf(sf)
            if sb and sb:IsShown() then sb:SetValue(sb:GetValue() - d * rowH * 2) end
        end)
        makeRow(row)
        list[i] = row
    end
    return sf, list
end

------------------------------------------------------------------------
-- Refresh
------------------------------------------------------------------------

local function LoadCategoryFields()
    local c = SelectedCategory()
    loadedCat = c
    nameBox:SetText(c and c.name or "")
    descBox:SetText(c and c.description or "")
    nameBox:ClearFocus()
    descBox:ClearFocus()
    SetCatStatus("")
end

local function UpdateCatList()
    local cats = Cats()
    FauxScrollFrame_Update(catScroll, #cats, CAT_ROWS, CAT_ROW_H)
    local off = FauxScrollFrame_GetOffset(catScroll)
    for i = 1, CAT_ROWS do
        local row, idx = catRows[i], off + i
        local c = cats[idx]
        if c then
            row.index = idx
            row.name:SetText(("%s  |cff888888(%d)|r"):format(c.name, #c.phrases))
            row.desc:SetText(c.description or "")
            row.sel:SetShown(idx == selCat)
            row:Show()
        else
            row:Hide()
        end
    end
end

local function UpdatePhraseList()
    local c = SelectedCategory()
    local phrases = c and c.phrases or {}
    FauxScrollFrame_Update(phScroll, #phrases, PH_ROWS, PH_ROW_H)
    local off = FauxScrollFrame_GetOffset(phScroll)
    for i = 1, PH_ROWS do
        local row, idx = phRows[i], off + i
        local p = phrases[idx]
        if p then
            row.index = idx
            row.text:SetText(p)
            row.sel:SetShown(idx == selPhrase)
            row:Show()
        else
            row:Hide()
        end
    end
end

local function UpdateButtons()
    local cats = Cats()
    local c = SelectedCategory()
    local function enable(b, on) if on then b:Enable() else b:Disable() end end
    enable(catButtons.delete, c ~= nil)
    enable(catButtons.up, c ~= nil and selCat > 1)
    enable(catButtons.down, c ~= nil and selCat < #cats)
    enable(catButtons.save, c ~= nil)
    enable(phButtons.add, c ~= nil)
    local p = c and selPhrase and c.phrases[selPhrase]
    enable(phButtons.edit, p ~= nil)
    enable(phButtons.delete, p ~= nil)
    enable(phButtons.up, p ~= nil and selPhrase > 1)
    enable(phButtons.down, p ~= nil and selPhrase < #c.phrases)
    if nameBox.Enable then
        if c then nameBox:Enable(); descBox:Enable() else nameBox:Disable(); descBox:Disable() end
    end
end

function ns.RefreshAdmin()
    if not admin or not admin:IsShown() then return end
    local cats = Cats()
    if #cats == 0 then selCat = nil
    elseif not selCat then selCat = 1
    elseif selCat > #cats then selCat = #cats
    elseif selCat < 1 then selCat = 1 end
    local c = SelectedCategory()
    if not c or not selPhrase or selPhrase > #c.phrases then selPhrase = nil end
    if c ~= loadedCat then LoadCategoryFields() end
    UpdateCatList()
    UpdatePhraseList()
    UpdateButtons()
end

------------------------------------------------------------------------
-- Category actions
------------------------------------------------------------------------

local function SelectCategory(idx)
    selCat = idx
    selPhrase = nil
    if FauxScrollFrame_SetOffset then FauxScrollFrame_SetOffset(phScroll, 0) end
    local sb = ScrollBarOf(phScroll)
    if sb then sb:SetValue(0) end
    ns.RefreshAdmin()
end

local function AddCategory()
    local base, name, n = "New category", "New category", 1
    while ns.FindCategory(name) do
        n = n + 1
        name = base .. " " .. n
    end
    local cats = Cats()
    cats[#cats + 1] = { name = name, description = "", phrases = {} }
    selCat = #cats
    selPhrase = nil
    ns.Changed()
    nameBox:SetFocus()
    nameBox:HighlightText()
    SetCatStatus("Type a name and description, then Save.")
end

local function SaveCategory()
    local c = SelectedCategory()
    if not c then return end
    local name = ns.Trim(nameBox:GetText())
    local desc = ns.Trim(descBox:GetText())
    if name == "" then SetCatStatus("Name can't be empty.", true); return end
    if name:find("|", 1, true) or desc:find("|", 1, true) then
        SetCatStatus("The | character isn't allowed.", true); return
    end
    local other = ns.FindCategory(name)
    if other and other ~= c then SetCatStatus("Another category already has that name.", true); return end
    if ns.settings.category == c.name then ns.settings.category = name end
    c.name = name
    c.description = desc
    loadedCat = nil -- reload fields with the trimmed values
    ns.Changed()
    SetCatStatus("Saved.")
end

local function DeleteCategory()
    local c = SelectedCategory()
    if not c then return end
    ns.Confirm(("Delete the category \"%s\" and its %d phrases?"):format(c.name, #c.phrases), function()
        for i, x in ipairs(Cats()) do
            if x == c then table.remove(Cats(), i); break end
        end
        ns.Changed()
    end)
end

local function MoveCategory(dir)
    local cats = Cats()
    local j = selCat and selCat + dir
    if not j or j < 1 or j > #cats then return end
    Swap(cats, selCat, j)
    selCat = j
    ns.Changed()
end

------------------------------------------------------------------------
-- Phrase editor
------------------------------------------------------------------------

local function UpdateEditor()
    if not editor or not editor:IsShown() then return end
    local text = editor.edit:GetText()
    local bytes = #text
    editor.counter:SetText(("%d / %d"):format(bytes, ns.MAX_BYTES))
    if bytes > ns.MAX_BYTES then editor.counter:SetTextColor(1, 0.3, 0.3)
    else editor.counter:SetTextColor(0.8, 0.8, 0.8) end

    local sub = ns.Substitute(text)
    local note = ""
    if #sub > ns.MAX_BYTES then note = "  |cffff8040(will be trimmed to fit 255)|r" end
    editor.preview:SetText(sub:gsub("|", "||") .. note)

    local err = ns.ValidatePhrase(text)
    if err and ns.Trim(text) ~= "" then
        editor.err:SetText(err)
    else
        editor.err:SetText("")
    end
    if err then editor.save:Disable() else editor.save:Enable() end
end
ns.RefreshPreview = UpdateEditor

local function CreateEditor()
    editor = ns.CreateBackdropFrame("Frame", "QuipsForeverPhraseEditor", UIParent, nil, "dialog")
    editor:SetSize(540, 250)
    editor:SetPoint("CENTER", 0, 40)
    editor:SetFrameStrata("FULLSCREEN")
    editor:SetToplevel(true)
    editor:EnableMouse(true)
    editor:SetMovable(true)
    editor:RegisterForDrag("LeftButton")
    editor:SetScript("OnDragStart", editor.StartMoving)
    editor:SetScript("OnDragStop", editor.StopMovingOrSizing)
    editor:Hide()
    tinsert(UISpecialFrames, "QuipsForeverPhraseEditor")

    editor.title = editor:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    editor.title:SetPoint("TOP", 0, -18)

    local hint = ns.MakeLabel(editor, "Placeholders: %t target   %n your name   %z zone   %c class   %r race", "GameFontHighlightSmall")
    hint:SetPoint("TOPLEFT", 24, -44)

    local box = ns.CreateBackdropFrame("Frame", nil, editor)
    box:SetPoint("TOPLEFT", 20, -60)
    box:SetSize(500, 72)
    box:EnableMouse(true)

    local edit = CreateFrame("EditBox", "QuipsForeverPhraseEditorEdit", box)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(ChatFontNormal)
    edit:SetPoint("TOPLEFT", 8, -8)
    edit:SetPoint("BOTTOMRIGHT", -8, 8)
    edit:SetMaxLetters(1000)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    edit:SetScript("OnTextChanged", function(self)
        local t = self:GetText()
        if t:find("[\r\n]") then
            self:SetText((t:gsub("[\r\n]+", " ")))
            return
        end
        UpdateEditor()
    end)
    box:SetScript("OnMouseDown", function() edit:SetFocus() end)
    editor.edit = edit

    editor.counter = editor:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    editor.counter:SetPoint("TOPRIGHT", box, "BOTTOMRIGHT", -4, -4)

    editor.err = editor:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    editor.err:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 4, -4)
    editor.err:SetTextColor(1, 0.3, 0.3)

    local plabel = ns.MakeLabel(editor, "Preview:", "GameFontNormalSmall")
    plabel:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 4, -22)
    editor.preview = editor:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    editor.preview:SetPoint("TOPLEFT", plabel, "TOPRIGHT", 6, 0)
    editor.preview:SetWidth(430)
    editor.preview:SetJustifyH("LEFT")
    editor.preview:SetJustifyV("TOP")

    editor.save = ns.MakeButton(editor, "Save", 100, 24, function()
        local text = ns.Trim(edit:GetText())
        if ns.ValidatePhrase(text) then return end
        if editor.onSave then editor.onSave(text) end
        editor:Hide()
    end)
    editor.save:SetPoint("BOTTOMRIGHT", editor, "BOTTOM", -6, 18)
    local cancel = ns.MakeButton(editor, "Cancel", 100, 24, function() editor:Hide() end)
    cancel:SetPoint("BOTTOMLEFT", editor, "BOTTOM", 6, 18)
end

local function OpenEditor(title, text, onSave)
    if not editor then CreateEditor() end
    editor.title:SetText(title)
    editor.onSave = onSave
    editor:Show()
    editor:Raise()
    editor.edit:SetText(text or "")
    editor.edit:SetFocus()
    editor.edit:SetCursorPosition(#(text or ""))
    UpdateEditor()
end

------------------------------------------------------------------------
-- Phrase actions
------------------------------------------------------------------------

local function AddPhrase()
    local c = SelectedCategory()
    if not c then return end
    OpenEditor("Add phrase to " .. c.name, "", function(text)
        c.phrases[#c.phrases + 1] = text
        selPhrase = #c.phrases
        ns.Changed()
        -- scroll so the new phrase is visible
        local sb = ScrollBarOf(phScroll)
        if sb then
            local _, maxV = sb:GetMinMaxValues()
            sb:SetValue(maxV)
        end
    end)
end

local function EditPhrase()
    local c = SelectedCategory()
    local idx = selPhrase
    if not c or not idx or not c.phrases[idx] then return end
    OpenEditor("Edit phrase", c.phrases[idx], function(text)
        c.phrases[idx] = text
        ns.Changed()
    end)
end

local function DeletePhrase()
    local c = SelectedCategory()
    local idx = selPhrase
    if not c or not idx or not c.phrases[idx] then return end
    local p = c.phrases[idx]
    local shown = #p > 60 and (p:sub(1, 57) .. "...") or p
    ns.Confirm(("Delete this phrase?\n\n\"%s\""):format(shown), function()
        table.remove(c.phrases, idx)
        selPhrase = nil
        ns.Changed()
    end)
end

local function MovePhrase(dir)
    local c = SelectedCategory()
    if not c or not selPhrase then return end
    local j = selPhrase + dir
    if j < 1 or j > #c.phrases then return end
    Swap(c.phrases, selPhrase, j)
    selPhrase = j
    ns.Changed()
end

------------------------------------------------------------------------
-- Window
------------------------------------------------------------------------

local function CreateAdmin()
    admin = ns.CreateBackdropFrame("Frame", "QuipsForeverAdmin", UIParent, nil, "dialog")
    admin:SetSize(680, 470)
    admin:SetPoint("CENTER")
    admin:SetFrameStrata("DIALOG")
    admin:SetToplevel(true)
    admin:EnableMouse(true)
    admin:SetMovable(true)
    admin:RegisterForDrag("LeftButton")
    admin:SetScript("OnDragStart", admin.StartMoving)
    admin:SetScript("OnDragStop", admin.StopMovingOrSizing)
    admin:SetClampedToScreen(true)
    admin:SetScript("OnShow", function() loadedCat = false; ns.RefreshAdmin() end)
    admin:SetScript("OnHide", function() if editor then editor:Hide() end end)
    admin:Hide()
    tinsert(UISpecialFrames, "QuipsForeverAdmin")

    local title = admin:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("Quips Forever: Phrasebook")
    local close = CreateFrame("Button", nil, admin, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)
    local info = ns.MakeButton(admin, "i", 24, 22, function() ns.ShowHelp() end)
    info:SetPoint("RIGHT", close, "LEFT", -2, 0)
    ns.AttachTooltip(info, function() return "How to use Quips Forever", "Opens the full instruction guide." end)

    -- Left: categories
    local lc = ns.MakeLabel(admin, "Categories")
    lc:SetPoint("TOPLEFT", 26, -46)

    catScroll, catRows = MakeList(admin, "QuipsForeverAdminCatScroll", 28, -68, 196, CAT_ROW_H, CAT_ROWS,
        function(row)
            row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
            row.name:SetPoint("TOPLEFT", 4, -2)
            row.name:SetPoint("RIGHT", -4, 0)
            row.name:SetJustifyH("LEFT")
            row.name:SetWordWrap(false)
            row.desc = row:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
            row.desc:SetPoint("TOPLEFT", 4, -16)
            row.desc:SetPoint("RIGHT", -4, 0)
            row.desc:SetJustifyH("LEFT")
            row.desc:SetWordWrap(false)
            row:SetScript("OnClick", function(self) SelectCategory(self.index) end)
        end,
        function() UpdateCatList() end)

    local y = -68 - CAT_ROW_H * CAT_ROWS - 12
    catButtons.add = ns.MakeButton(admin, "Add", 108, 22, AddCategory)
    catButtons.add:SetPoint("TOPLEFT", 22, y)
    catButtons.delete = ns.MakeButton(admin, "Delete", 108, 22, DeleteCategory)
    catButtons.delete:SetPoint("LEFT", catButtons.add, "RIGHT", 4, 0)
    catButtons.up = ns.MakeButton(admin, "Move up", 108, 22, function() MoveCategory(-1) end)
    catButtons.up:SetPoint("TOPLEFT", catButtons.add, "BOTTOMLEFT", 0, -4)
    catButtons.down = ns.MakeButton(admin, "Move down", 108, 22, function() MoveCategory(1) end)
    catButtons.down:SetPoint("LEFT", catButtons.up, "RIGHT", 4, 0)
    catButtons.io = ns.MakeButton(admin, "Import / Export", 220, 22, function() ns.ShowImportExport() end)
    catButtons.io:SetPoint("TOPLEFT", catButtons.up, "BOTTOMLEFT", 0, -4)

    -- Right: selected category
    local X = 282
    local ln = ns.MakeLabel(admin, "Name", "GameFontNormalSmall")
    ln:SetPoint("TOPLEFT", X, -50)
    nameBox = ns.MakeEditBox(admin, 230)
    nameBox:SetPoint("TOPLEFT", X + 82, -45)
    nameBox:SetMaxLetters(60)
    nameBox:SetScript("OnEnterPressed", function(self) self:ClearFocus(); SaveCategory() end)

    local ld = ns.MakeLabel(admin, "Description", "GameFontNormalSmall")
    ld:SetPoint("TOPLEFT", X, -76)
    descBox = ns.MakeEditBox(admin, 290)
    descBox:SetPoint("TOPLEFT", X + 82, -71)
    descBox:SetMaxLetters(200)
    descBox:SetScript("OnEnterPressed", function(self) self:ClearFocus(); SaveCategory() end)

    catButtons.save = ns.MakeButton(admin, "Save category", 120, 22, SaveCategory)
    catButtons.save:SetPoint("TOPLEFT", X + 76, -98)
    catStatus = admin:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    catStatus:SetPoint("LEFT", catButtons.save, "RIGHT", 10, 0)
    catStatus:SetPoint("RIGHT", admin, "RIGHT", -24, 0)
    catStatus:SetJustifyH("LEFT")

    local lp = ns.MakeLabel(admin, "Phrases")
    lp:SetPoint("TOPLEFT", X, -132)

    phScroll, phRows = MakeList(admin, "QuipsForeverAdminPhraseScroll", X + 2, -154, 340, PH_ROW_H, PH_ROWS,
        function(row)
            row.text = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            row.text:SetPoint("LEFT", 4, 0)
            row.text:SetPoint("RIGHT", -4, 0)
            row.text:SetJustifyH("LEFT")
            row.text:SetWordWrap(false)
            row:SetScript("OnClick", function(self)
                selPhrase = self.index
                ns.RefreshAdmin()
            end)
            row:SetScript("OnDoubleClick", function(self)
                selPhrase = self.index
                ns.RefreshAdmin()
                EditPhrase()
            end)
            ns.AttachTooltip(row, function(self)
                local c = SelectedCategory()
                local p = c and self.index and c.phrases[self.index]
                if not p then return nil end
                return ("Phrase %d  (%d / %d)"):format(self.index, #p, ns.MAX_BYTES), p
            end)
        end,
        function() UpdatePhraseList() end)

    local py = -154 - PH_ROW_H * PH_ROWS - 12
    phButtons.add = ns.MakeButton(admin, "Add", 68, 22, AddPhrase)
    phButtons.add:SetPoint("TOPLEFT", X - 2, py)
    phButtons.edit = ns.MakeButton(admin, "Edit", 68, 22, EditPhrase)
    phButtons.edit:SetPoint("LEFT", phButtons.add, "RIGHT", 4, 0)
    phButtons.delete = ns.MakeButton(admin, "Delete", 68, 22, DeletePhrase)
    phButtons.delete:SetPoint("LEFT", phButtons.edit, "RIGHT", 4, 0)
    phButtons.up = ns.MakeButton(admin, "Move up", 76, 22, function() MovePhrase(-1) end)
    phButtons.up:SetPoint("LEFT", phButtons.delete, "RIGHT", 4, 0)
    phButtons.down = ns.MakeButton(admin, "Move down", 82, 22, function() MovePhrase(1) end)
    phButtons.down:SetPoint("LEFT", phButtons.up, "RIGHT", 4, 0)

    local tip = ns.MakeLabel(admin, "Double-click a phrase to edit it.", "GameFontDisableSmall")
    tip:SetPoint("TOPLEFT", phButtons.add, "BOTTOMLEFT", 4, -8)
end

function ns.ShowAdmin()
    if not admin then CreateAdmin() end
    ns.HideMenu()
    if admin:IsShown() then admin:Raise() else admin:Show() end
end
