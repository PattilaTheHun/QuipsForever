-- Quips Forever: data model, placeholders, shuffle bag, sending, shared UI helpers, slash commands.
local ADDON_NAME, ns = ...

ns.MAX_BYTES = 255
ns.dataVersion = 0

ns.CHANNELS = {
    { key = "SAY",   label = "Say" },
    { key = "PARTY", label = "Party" },
    { key = "GUILD", label = "Guild" },
    { key = "EMOTE", label = "Emote" },
}

------------------------------------------------------------------------
-- Utilities
------------------------------------------------------------------------

function ns.Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff66ccffQuips Forever:|r " .. tostring(msg))
end

function ns.Trim(s)
    local out = (s or ""):gsub("^%s+", ""):gsub("%s+$", "")
    return out
end

local function DeepCopy(t)
    if type(t) ~= "table" then return t end
    local out = {}
    for k, v in pairs(t) do out[k] = DeepCopy(v) end
    return out
end
ns.DeepCopy = DeepCopy

-- Cut a string to at most maxBytes without splitting a UTF-8 character.
function ns.TruncateUTF8(s, maxBytes)
    if #s <= maxBytes then return s end
    s = s:sub(1, maxBytes)
    local i = #s
    while i > 0 do
        local b = s:byte(i)
        if b < 0x80 then break end          -- plain ASCII, nothing cut
        if b >= 0xC0 then                    -- lead byte: is its sequence complete?
            local need = (b >= 0xF0 and 4) or (b >= 0xE0 and 3) or 2
            if #s - i + 1 < need then s = s:sub(1, i - 1) end
            break
        end
        i = i - 1
    end
    return s
end

------------------------------------------------------------------------
-- Saved data
------------------------------------------------------------------------

local function InitDB()
    if type(QuipsForeverDB) ~= "table" then QuipsForeverDB = {} end
    local db = QuipsForeverDB
    if type(db.categories) ~= "table" then
        db.categories = DeepCopy(ns.DEFAULT_CATEGORIES)
    end
    db.version = 1
    if type(db.settings) ~= "table" then db.settings = {} end
    local s = db.settings
    if s.channel == nil then s.channel = "SAY" end
    if s.collapsed == nil then s.collapsed = false end
    if s.locked == nil then s.locked = false end
    if s.hidden == nil then s.hidden = false end

    -- Clean up anything malformed
    for i = #db.categories, 1, -1 do
        local c = db.categories[i]
        if type(c) ~= "table" or type(c.name) ~= "string" then
            table.remove(db.categories, i)
        else
            if type(c.description) ~= "string" then c.description = "" end
            if type(c.phrases) ~= "table" then c.phrases = {} end
        end
    end

    if type(QuipsForeverCharDB) ~= "table" then QuipsForeverCharDB = {} end
    ns.db = db
    ns.charDB = QuipsForeverCharDB
    ns.settings = s
    if not ns.FindCategory(s.category) then
        s.category = db.categories[1] and db.categories[1].name or nil
    end
end

function ns.Categories()
    return ns.db.categories
end

function ns.FindCategory(name)
    if not name or not ns.db then return nil end
    local lname = name:lower()
    for i, c in ipairs(ns.db.categories) do
        if c.name:lower() == lname then return c, i end
    end
    return nil
end

function ns.CurrentCategory()
    local c = ns.FindCategory(ns.settings.category)
    if not c then
        c = ns.db.categories[1]
        ns.settings.category = c and c.name or nil
    end
    return c
end

-- Call after any change to categories or phrases.
function ns.Changed()
    ns.dataVersion = ns.dataVersion + 1
    if ns.RefreshBar then ns.RefreshBar() end
    if ns.RefreshAdmin then ns.RefreshAdmin() end
end

-- Returns nil if the raw phrase is acceptable, otherwise a message.
function ns.ValidatePhrase(text)
    if not text or ns.Trim(text) == "" then return "Phrase is empty." end
    if text:find("[\r\n]") then return "Phrase must be a single line." end
    if text:find("|", 1, true) then return "The | character can't be sent in chat." end
    if #text > ns.MAX_BYTES then
        return ("Phrase is too long (%d / %d)."):format(#text, ns.MAX_BYTES)
    end
    return nil
end

------------------------------------------------------------------------
-- Placeholders
------------------------------------------------------------------------

local function PlaceholderValue(key)
    if key == "t" then
        if UnitExists("target") then
            local n = UnitName("target")
            if n and n ~= "" then return n end
        end
        return "friend"
    elseif key == "n" then
        return UnitName("player") or ""
    elseif key == "z" then
        local z = GetZoneText and GetZoneText() or ""
        if not z or z == "" then z = GetRealZoneText and GetRealZoneText() or "" end
        if not z or z == "" then z = "these parts" end
        return z
    elseif key == "c" then
        return (UnitClass("player")) or ""
    elseif key == "r" then
        return (UnitRace("player")) or ""
    end
end

function ns.Substitute(text)
    return (text:gsub("%%([tnzcr])", PlaceholderValue))
end

-- The exact text that would go out, or nil plus a reason.
function ns.Prepare(raw)
    local text = ns.Substitute(raw or ""):gsub("[\r\n]", " ")
    text = ns.Trim(text)
    if text == "" then return nil, "Nothing to send." end
    if text:find("|", 1, true) then return nil, "The | character can't be sent in chat." end
    return ns.TruncateUTF8(text, ns.MAX_BYTES)
end

------------------------------------------------------------------------
-- Sending (only ever called from a click handler)
------------------------------------------------------------------------

local function InGroup()
    if IsInGroup then return IsInGroup() end
    if GetNumGroupMembers then return GetNumGroupMembers() > 0 end
    if GetNumPartyMembers then return GetNumPartyMembers() > 0 end
    return false
end

local function SendRaw(text, chatType)
    if SendChatMessage then
        SendChatMessage(text, chatType)
    elseif C_ChatInfo and C_ChatInfo.SendChatMessage then
        C_ChatInfo.SendChatMessage(text, chatType)
    end
end

function ns.Send(raw)
    local text, err = ns.Prepare(raw)
    if not text then ns.Print(err); return end
    local chan = ns.settings.channel or "SAY"
    if chan == "PARTY" and not InGroup() then
        ns.Print("You are not in a party.")
        return
    elseif chan == "GUILD" and not IsInGuild() then
        ns.Print("You are not in a guild.")
        return
    end
    SendRaw(text, chan)
end

------------------------------------------------------------------------
-- Random (shuffle bag per category, resets on login)
------------------------------------------------------------------------

local bags = {}

function ns.SendRandom()
    local cat = ns.CurrentCategory()
    if not cat or #cat.phrases == 0 then
        ns.Print("This category has no phrases yet.")
        return
    end
    local key = cat.name:lower()
    local bag = bags[key]
    if not bag or bag.version ~= ns.dataVersion or #bag.list == 0 then
        local last = bag and bag.last
        local list = {}
        for i = 1, #cat.phrases do list[i] = i end
        for i = #list, 2, -1 do
            local j = math.random(i)
            list[i], list[j] = list[j], list[i]
        end
        -- avoid repeating the previous phrase right after a refill
        if last and #list > 1 and list[#list] == last then
            list[#list], list[1] = list[1], list[#list]
        end
        bag = { version = ns.dataVersion, list = list, last = last }
        bags[key] = bag
    end
    local idx = table.remove(bag.list)
    bag.last = idx
    ns.Send(cat.phrases[idx])
end

------------------------------------------------------------------------
-- Shared UI helpers
------------------------------------------------------------------------

local nameCounter = 0
function ns.UniqueName(prefix)
    nameCounter = nameCounter + 1
    return "QuipsForever" .. prefix .. nameCounter
end

local BACKDROPS = {
    panel = {
        bgFile = "Interface\\Tooltips\\UI-Tooltip-Background",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 16,
        insets = { left = 4, right = 4, top = 4, bottom = 4 },
    },
    dialog = {
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    },
}

-- CreateFrame that works whether or not the client needs BackdropTemplate.
function ns.CreateBackdropFrame(frameType, name, parent, template, style)
    local tpl = template
    if BackdropTemplateMixin then
        tpl = tpl and (tpl .. ",BackdropTemplate") or "BackdropTemplate"
    end
    local f = CreateFrame(frameType, name, parent, tpl)
    if f.SetBackdrop then
        f:SetBackdrop(BACKDROPS[style or "panel"])
        if (style or "panel") == "panel" then
            f:SetBackdropColor(0.05, 0.05, 0.05, 0.9)
            f:SetBackdropBorderColor(0.6, 0.6, 0.6, 1)
        end
    end
    return f
end

function ns.MakeButton(parent, text, width, height, onClick)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width or 80, height or 22)
    b:SetText(text)
    if onClick then b:SetScript("OnClick", onClick) end
    return b
end

function ns.MakeEditBox(parent, width)
    local e = CreateFrame("EditBox", ns.UniqueName("Edit"), parent, "InputBoxTemplate")
    e:SetSize(width or 150, 20)
    e:SetAutoFocus(false)
    e:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    e:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
    return e
end

function ns.MakeLabel(parent, text, font)
    local fs = parent:CreateFontString(nil, "OVERLAY", font or "GameFontNormal")
    fs:SetText(text or "")
    fs:SetJustifyH("LEFT")
    return fs
end

-- Simple tooltip. lines is a function returning title, body (body optional).
function ns.AttachTooltip(frame, lines)
    frame:HookScript("OnEnter", function(self)
        local title, body = lines(self)
        if not title then return end
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        GameTooltip:SetText(title, 1, 0.82, 0)
        if body and body ~= "" then GameTooltip:AddLine(body, 1, 1, 1, true) end
        GameTooltip:Show()
    end)
    frame:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

-- Confirmation dialog
StaticPopupDialogs["QUIPSFOREVER_CONFIRM"] = {
    text = "%s",
    button1 = YES or "Yes",
    button2 = NO or "No",
    OnAccept = function(self, data) if data then data() end end,
    timeout = 0,
    whileDead = true,
    hideOnEscape = true,
    preferredIndex = 3,
}

function ns.Confirm(text, onAccept)
    StaticPopup_Show("QUIPSFOREVER_CONFIRM", text, nil, onAccept)
end

------------------------------------------------------------------------
-- Pop-up menu (used for dropdowns and the right-click menu)
------------------------------------------------------------------------

local menu, menuButtons, menuOwner = nil, {}, nil

local function IsOver(f)
    if f.IsMouseOver then return f:IsMouseOver() end
    if MouseIsOver then return MouseIsOver(f) end
    return false
end

local function HideMenu()
    if menu then menu:Hide() end
    menuOwner = nil
end
ns.HideMenu = HideMenu

-- items = { { text = "...", checked = bool, func = function() end }, ... }
function ns.ToggleMenu(owner, items)
    if menu and menu:IsShown() and menuOwner == owner then
        HideMenu()
        return
    end
    if not menu then
        menu = ns.CreateBackdropFrame("Frame", "QuipsForeverMenu", UIParent)
        menu:SetFrameStrata("FULLSCREEN_DIALOG")
        menu:SetClampedToScreen(true)
        menu:EnableMouse(true)
        menu:Hide()
        if pcall(menu.RegisterEvent, menu, "GLOBAL_MOUSE_DOWN") then
            menu:SetScript("OnEvent", function(self)
                if self:IsShown() and not IsOver(self)
                    and not (menuOwner and IsOver(menuOwner)) then
                    HideMenu()
                end
            end)
        end
        tinsert(UISpecialFrames, "QuipsForeverMenu")
    end
    for _, b in ipairs(menuButtons) do b:Hide() end

    local maxW = 80
    for i, item in ipairs(items) do
        local b = menuButtons[i]
        if not b then
            b = CreateFrame("Button", nil, menu)
            b:SetHeight(18)
            b:SetHighlightTexture("Interface\\QuestFrame\\UI-QuestTitleHighlight", "ADD")
            b.check = b:CreateTexture(nil, "ARTWORK")
            b.check:SetTexture("Interface\\Buttons\\UI-CheckBox-Check")
            b.check:SetSize(16, 16)
            b.check:SetPoint("LEFT", 2, 0)
            b.text = b:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
            b.text:SetPoint("LEFT", 20, 0)
            b.text:SetJustifyH("LEFT")
            menuButtons[i] = b
        end
        b.text:SetText(item.text)
        b.check:SetShown(item.checked and true or false)
        b:SetScript("OnClick", function()
            HideMenu()
            if item.func then item.func() end
        end)
        b:ClearAllPoints()
        b:SetPoint("TOPLEFT", menu, "TOPLEFT", 6, -6 - (i - 1) * 18)
        b:Show()
        maxW = math.max(maxW, b.text:GetStringWidth() + 30)
    end
    for i = 1, #items do menuButtons[i]:SetWidth(maxW) end
    menu:SetSize(maxW + 12, #items * 18 + 12)
    menu:ClearAllPoints()
    menu:SetPoint("TOPLEFT", owner, "BOTTOMLEFT", 0, -2)
    menuOwner = owner
    menu:Show()
end

------------------------------------------------------------------------
-- Events and slash commands
------------------------------------------------------------------------

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_TARGET_CHANGED")
events:RegisterEvent("ZONE_CHANGED_NEW_AREA")
events:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        InitDB()
    elseif event == "PLAYER_LOGIN" then
        if ns.CreateBar then ns.CreateBar() end
    elseif event == "PLAYER_TARGET_CHANGED" or event == "ZONE_CHANGED_NEW_AREA" then
        if ns.RefreshPreview then ns.RefreshPreview() end
    end
end)

SLASH_QUIPSFOREVER1 = "/quips"
SlashCmdList["QUIPSFOREVER"] = function(msg)
    local cmd = ns.Trim(msg):lower()
    if cmd == "" then
        ns.ToggleBar()
    elseif cmd == "admin" then
        ns.ShowAdmin()
    elseif cmd == "lock" then
        ns.SetLocked(true)
    elseif cmd == "unlock" then
        ns.SetLocked(false)
    elseif cmd == "reset" then
        ns.ResetBarPosition()
    elseif cmd == "help" then
        ns.ShowHelp()
    else
        ns.Print("/quips  show or hide the bar")
        ns.Print("/quips admin  open the phrasebook editor")
        ns.Print("/quips help  open the instruction guide")
        ns.Print("/quips lock, /quips unlock  lock or unlock the bar")
        ns.Print("/quips reset  move the bar back to its default spot")
    end
end
