-- Quips Forever: the instruction guide window (the "i" button in the phrasebook editor, or /quips help).
local _, ns = ...

-- Note: a literal vertical bar must be written as || in these strings.
local SECTIONS = {
    { "Welcome",
      "Quips Forever sends saved phrases to chat with one click. Your phrases live in categories, like Greetings, Dungeon Etiquette or Campfire Jokes, so the right line is always a click away. Nothing is ever sent without you clicking." },

    { "The bar",
      "Quips Forever: the black title strip. Drag it to move the bar. Right-click it for options.\n" ..
      "Gray grip (far left): also drags the bar and right-clicks for options.\n" ..
      "Channel (Say, Party, Guild, Emote): where your phrases go.\n" ..
      "Category: pick which set of phrases to show. Picking one always opens the phrase list.\n" ..
      "Dice: sends a random phrase from the current category.\n" ..
      "Search: type to filter the list. Click the small x to clear it.\n" ..
      "Gear: opens the phrasebook editor.\n" ..
      "Plus / minus: opens or closes the phrase list.\n" ..
      "Corner grabber (bottom right): drag up or down to show more or fewer phrases (3 to 30)." },

    { "Sending a phrase",
      "Click anywhere on a phrase row, or its Say button. The phrase goes to the selected channel and the list closes. Pick a category to open it again.\n\n" ..
      "Hover over a row first to see exactly what will be sent, with placeholders filled in.\n\n" ..
      "Party and Guild only work when you are in a party or guild. Otherwise you get a note in chat and nothing is sent.\n\n" ..
      "Emote puts your name in front automatically, so write emote phrases in the third person. For example \"warms his hands by the fire\" comes out as \"Thrall warms his hands by the fire\"." },

    { "Placeholders",
      "Put these codes in a phrase and they are filled in when you send it:\n" ..
      "%t   your current target's name (or \"friend\" if you have no target)\n" ..
      "%n   your character's name\n" ..
      "%z   the zone you are in (or \"these parts\")\n" ..
      "%c   your class, like Warrior\n" ..
      "%r   your race, like Troll\n\n" ..
      "Example: \"Well met, %t! Safe travels through %z.\"\n" ..
      "A percent sign on its own, as in \"100% ready\", is left alone." },

    { "Random phrases",
      "The dice works like a shuffled deck. Every phrase in the category comes up once before any repeats. The deck reshuffles when you log in or change the phrasebook. The dice does not close the list." },

    { "Moving, locking and hiding",
      "Drag the title strip or the grip to move the bar. Right-click either one for:\n" ..
      "Lock bar / Unlock bar: a locked bar can't be moved or resized by accident.\n" ..
      "Reset position: puts the bar back in the top left.\n" ..
      "Open phrasebook editor.\n" ..
      "Hide bar: type /quips to bring it back.\n\n" ..
      "Each character remembers its own bar position and height. The bar stays hidden across logins until you show it again." },

    { "The phrasebook editor",
      "Open it with the gear on the bar or /quips admin.\n\n" ..
      "Left side, Categories: click one to select it. Add makes a new one, Delete removes it and all its phrases (you are asked first). Move up and Move down change the order on the bar's menu. Import / Export opens the text window.\n\n" ..
      "Right side, the selected category: change its Name or Description, then click Save category (or press Enter). Names must be unique.\n\n" ..
      "Phrases: Add, Edit, Delete, Move up and Move down. Double-click a phrase to edit it.\n\n" ..
      "The phrase editor shows a counter like \"212 / 255\" and a preview with placeholders filled in for your current target and zone. Save is grayed out when the phrase is empty, too long, or contains the vertical bar character (||)." },

    { "Import and Export",
      "This is the easy way to write lots of phrases in Notepad and bring them into the game.\n\n" ..
      "Export fills the box with your whole phrasebook and selects it. Press Ctrl+C to copy, then paste into Notepad. Keep that file as your backup.\n\n" ..
      "To bring text in, click in the box, press Ctrl+V to paste, then choose:\n" ..
      "Import (replace): your whole phrasebook is replaced by the pasted text.\n" ..
      "Merge: new categories are added and new phrases are added to matching categories. Nothing is deleted, and phrases you already have are skipped.\n" ..
      "Either way you see how many categories and phrases were found and confirm before anything changes. Clear empties the box." },

    { "The text format",
      "Three kinds of lines:\n" ..
      "#   starts a category and names it\n" ..
      "##   the description of that category (optional)\n" ..
      "-   one phrase\n\n" ..
      "# Campfire Jokes\n" ..
      "## Funny WoW-themed jokes to say around a campfire\n" ..
      "- You know what this fire needs? One guy with a guitar.\n" ..
      "- Every campfire eventually turns into a talk about crypto.\n\n" ..
      "# Dungeon Etiquette\n" ..
      "## Things to say at the start of a run\n" ..
      "- Hey all, %n here. Happy to tank, just call out if I pull too fast.\n\n" ..
      "Blank lines and leading spaces are fine. If any line breaks the rules, the import is cancelled and each problem is listed with its line number, so nothing half-imports." },

    { "Rules and limits",
      "One line per phrase.\n" ..
      "Up to 255 characters. Accented letters and curly quotes count as 2 or 3, which is why the counter may jump.\n" ..
      "No vertical bar character (||). The game reads it as a special code.\n" ..
      "If placeholders make a phrase longer than 255, the end is trimmed when it is sent." },

    { "Slash commands",
      "/quips   show or hide the bar\n" ..
      "/quips admin   open the phrasebook editor\n" ..
      "/quips help   open this guide\n" ..
      "/quips lock   and   /quips unlock\n" ..
      "/quips reset   move the bar back to the top left" },

    { "Where your phrases are saved",
      "Your phrasebook is shared by every character on your account. It is saved by the game when you log out or type /reload, in:\n" ..
      "World of Warcraft\\_classic_beta_\\WTF\\Account\\(your account)\\SavedVariables\\QuipsForever.lua\n\n" ..
      "The simplest backup is Export, then save the text in Notepad." },

    { "Troubleshooting",
      "The bar is gone: type /quips. If it is off screen, type /quips reset.\n" ..
      "Can't move or resize the bar: it is locked. Right-click the title and choose Unlock bar, or type /quips unlock.\n" ..
      "The phrase list is empty: click the plus button, or pick a category. If a search is active, click the x in the search box.\n" ..
      "Nothing happens in Party or Guild: you are not in one. Check chat for a note.\n" ..
      "To see Lua errors, type /console scriptErrors 1." },
}

local win, content, blocks

local function Layout()
    local width = content:GetWidth()
    local y = -4
    for _, b in ipairs(blocks) do
        b.h:SetWidth(width)
        b.b:SetWidth(width)
        b.h:ClearAllPoints()
        b.h:SetPoint("TOPLEFT", content, "TOPLEFT", 0, y)
        y = y - b.h:GetStringHeight() - 6
        b.b:ClearAllPoints()
        b.b:SetPoint("TOPLEFT", content, "TOPLEFT", 0, y)
        y = y - b.b:GetStringHeight() - 18
    end
    content:SetHeight(-y + 10)
end

local function CreateWindow()
    win = ns.CreateBackdropFrame("Frame", "QuipsForeverHelp", UIParent, nil, "dialog")
    win:SetSize(600, 520)
    win:SetPoint("CENTER", 40, 0)
    win:SetFrameStrata("FULLSCREEN")
    win:SetToplevel(true)
    win:EnableMouse(true)
    win:SetMovable(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:SetClampedToScreen(true)
    win:Hide()
    tinsert(UISpecialFrames, "QuipsForeverHelp")

    local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("Quips Forever: How to Use")
    local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local box = ns.CreateBackdropFrame("Frame", nil, win)
    box:SetPoint("TOPLEFT", 20, -46)
    box:SetPoint("BOTTOMRIGHT", -20, 54)

    local scroll = CreateFrame("ScrollFrame", "QuipsForeverHelpScroll", box, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 12, -10)
    scroll:SetPoint("BOTTOMRIGHT", -30, 10)

    content = CreateFrame("Frame", nil, scroll)
    content:SetSize(510, 100)
    scroll:SetScrollChild(content)

    blocks = {}
    for i, s in ipairs(SECTIONS) do
        local h = content:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
        h:SetJustifyH("LEFT")
        h:SetText(s[1])
        local b = content:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        b:SetJustifyH("LEFT")
        b:SetJustifyV("TOP")
        b:SetSpacing(2)
        b:SetText(s[2])
        blocks[i] = { h = h, b = b }
    end

    scroll:SetScript("OnSizeChanged", function(self, w)
        content:SetWidth(math.max(100, w - 4))
        Layout()
    end)
    win:SetScript("OnShow", Layout)

    local done = ns.MakeButton(win, "Close", 100, 24, function() win:Hide() end)
    done:SetPoint("BOTTOM", 0, 20)
end

function ns.ShowHelp()
    if not win then CreateWindow() end
    win:Show()
    win:Raise()
    Layout()
end
