QUIPS FOREVER  v1.1.0
One click sends a saved phrase to chat.
For the WoW Forever client (Interface 16001).

INSTALL
1. Close World of Warcraft.
2. Unzip this file. You get a folder named QuipsForever.
3. Move that folder into:
   World of Warcraft\_classic_beta_\Interface\AddOns\
   so the files end up in ...\Interface\AddOns\QuipsForever\QuipsForever.toc
   (Not ...\AddOns\QuipsForever\QuipsForever\. If you see a double folder, move the inner one up.)
4. Start the game. At the character screen click AddOns and make sure Quips Forever is checked.
5. Log in and type /quips

GETTING STARTED
- The bar appears in the top left with three sample categories.
- Pick a channel (Say, Party, Guild, Emote) and a category, then click a phrase.
- Click the gear to add your own phrases, then the "i" button in that window for the full guide.
- Type /quips help at any time for the guide.

UPDATING
Close the game, delete the old QuipsForever folder, and put the new one in its place.
Your phrases are kept. They are stored in WTF\Account\(your account)\SavedVariables\QuipsForever.lua, not in the addon folder.

UNINSTALL
Delete the QuipsForever folder from Interface\AddOns.
