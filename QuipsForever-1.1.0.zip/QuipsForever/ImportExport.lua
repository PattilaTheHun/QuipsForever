-- Quips Forever: text format parser and writer, plus the Import / Export window.
--
--   # Category name
--   ## Category description
--   - A phrase
--
-- Blank lines are ignored. Any other line is an error.
local _, ns = ...

------------------------------------------------------------------------
-- Parser and writer (no UI, testable outside the game)
------------------------------------------------------------------------

-- Returns categories, errors. errors is a list of strings; empty means success.
function ns.ParseText(text)
    local cats, errors, current, seen = {}, {}, nil, {}
    local lineNo = 0
    text = (text or ""):gsub("\r\n", "\n"):gsub("\r", "\n")
    for line in (text .. "\n"):gmatch("([^\n]*)\n") do
        lineNo = lineNo + 1
        local l = ns.Trim(line)
        if l == "" then
            -- skip
        elseif l:sub(1, 2) == "##" then
            if not current then
                errors[#errors + 1] = ("Line %d: description comes before any # category."):format(lineNo)
            elseif l:find("|", 1, true) then
                errors[#errors + 1] = ("Line %d: the | character isn't allowed."):format(lineNo)
            else
                current.description = ns.Trim(l:sub(3))
            end
        elseif l:sub(1, 1) == "#" then
            local name = ns.Trim(l:sub(2))
            if name == "" then
                errors[#errors + 1] = ("Line %d: category name is empty."):format(lineNo)
                current = nil
            elseif name:find("|", 1, true) then
                errors[#errors + 1] = ("Line %d: the | character isn't allowed."):format(lineNo)
                current = nil
            elseif seen[name:lower()] then
                errors[#errors + 1] = ("Line %d: category \"%s\" appears twice."):format(lineNo, name)
                current = seen[name:lower()]
            else
                current = { name = name, description = "", phrases = {} }
                seen[name:lower()] = current
                cats[#cats + 1] = current
            end
        elseif l:sub(1, 1) == "-" then
            local phrase = ns.Trim(l:sub(2))
            if not current then
                errors[#errors + 1] = ("Line %d: phrase comes before any # category."):format(lineNo)
            else
                local err = ns.ValidatePhrase(phrase)
                if err then
                    errors[#errors + 1] = ("Line %d: %s"):format(lineNo, err)
                else
                    current.phrases[#current.phrases + 1] = phrase
                end
            end
        else
            errors[#errors + 1] = ("Line %d: doesn't start with #, ## or -."):format(lineNo)
        end
    end
    return cats, errors
end

function ns.WriteText(cats)
    local out = {}
    for i, c in ipairs(cats) do
        if i > 1 then out[#out + 1] = "" end
        out[#out + 1] = "# " .. c.name
        if c.description and c.description ~= "" then
            out[#out + 1] = "## " .. c.description
        end
        for _, p in ipairs(c.phrases) do
            out[#out + 1] = "- " .. p
        end
    end
    return table.concat(out, "\n") .. "\n"
end

local function CountPhrases(cats)
    local n = 0
    for _, c in ipairs(cats) do n = n + #c.phrases end
    return n
end
ns.CountPhrases = CountPhrases

-- Adds new categories and appends phrases not already present.
-- Returns newCategories, newPhrases.
function ns.MergeInto(target, incoming)
    local newCats, newPhrases = 0, 0
    for _, inc in ipairs(incoming) do
        local existing
        for _, c in ipairs(target) do
            if c.name:lower() == inc.name:lower() then existing = c; break end
        end
        if not existing then
            target[#target + 1] = inc
            newCats = newCats + 1
            newPhrases = newPhrases + #inc.phrases
        else
            if (existing.description or "") == "" and inc.description ~= "" then
                existing.description = inc.description
            end
            local have = {}
            for _, p in ipairs(existing.phrases) do have[p] = true end
            for _, p in ipairs(inc.phrases) do
                if not have[p] then
                    existing.phrases[#existing.phrases + 1] = p
                    have[p] = true
                    newPhrases = newPhrases + 1
                end
            end
        end
    end
    return newCats, newPhrases
end

-- Counts what a merge would add, without changing anything.
local function PreviewMerge(target, incoming)
    return ns.MergeInto(ns.DeepCopy(target), ns.DeepCopy(incoming))
end

------------------------------------------------------------------------
-- Window
------------------------------------------------------------------------

local win

local function Plural(n, word)
    return n .. " " .. word .. (n == 1 and "" or "s")
end

local function CatWord(n)
    return n .. (n == 1 and " category" or " categories")
end

local function ShowErrors(errors)
    local shown = math.min(#errors, 3)
    local lines = {}
    for i = 1, shown do lines[i] = errors[i] end
    if #errors > shown then lines[#lines + 1] = ("...and %d more (see chat)."):format(#errors - shown) end
    win.status:SetTextColor(1, 0.3, 0.3)
    win.status:SetText("Import cancelled.\n" .. table.concat(lines, "\n"))
    ns.Print("Import cancelled:")
    for _, e in ipairs(errors) do ns.Print("  " .. e) end
end

local function SetStatus(msg)
    win.status:SetTextColor(1, 0.82, 0)
    win.status:SetText(msg or "")
end

local function DoExport()
    local text = ns.WriteText(ns.Categories())
    win.edit:SetText(text)
    win.edit:SetFocus()
    win.edit:HighlightText()
    SetStatus(("Exported %s and %s. Press Ctrl+C to copy.")
        :format(CatWord(#ns.Categories()), Plural(CountPhrases(ns.Categories()), "phrase")))
end

local function DoImport(merge)
    local cats, errors = ns.ParseText(win.edit:GetText())
    if #errors > 0 then ShowErrors(errors); return end
    if #cats == 0 then SetStatus("Nothing to import. Paste your phrasebook into the box first."); return end
    local nPhrases = CountPhrases(cats)
    if merge then
        local nc, np = PreviewMerge(ns.Categories(), cats)
        ns.Confirm(("Found %s and %s.\nMerge adds %s and %s.\nNothing is deleted. Continue?")
            :format(CatWord(#cats), Plural(nPhrases, "phrase"), CatWord(nc), Plural(np, "new phrase")),
            function()
                ns.MergeInto(ns.Categories(), cats)
                ns.Changed()
                SetStatus(("Merged: added %s and %s."):format(CatWord(nc), Plural(np, "phrase")))
            end)
    else
        ns.Confirm(("Found %s and %s.\nReplace your whole phrasebook with these?")
            :format(CatWord(#cats), Plural(nPhrases, "phrase")),
            function()
                local db = ns.db
                wipe(db.categories)
                for i, c in ipairs(cats) do db.categories[i] = c end
                ns.settings.category = cats[1].name
                ns.Changed()
                SetStatus(("Imported %s and %s."):format(CatWord(#cats), Plural(nPhrases, "phrase")))
            end)
    end
end

local function CreateWindow()
    win = ns.CreateBackdropFrame("Frame", "QuipsForeverImportExport", UIParent, nil, "dialog")
    win:SetSize(580, 480)
    win:SetPoint("CENTER")
    win:SetFrameStrata("DIALOG")
    win:SetToplevel(true)
    win:EnableMouse(true)
    win:SetMovable(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", win.StartMoving)
    win:SetScript("OnDragStop", win.StopMovingOrSizing)
    win:SetClampedToScreen(true)
    win:Hide()
    tinsert(UISpecialFrames, "QuipsForeverImportExport")

    local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -18)
    title:SetText("Quips Forever: Import / Export")

    local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    local help = ns.MakeLabel(win, "Format:  # Category   ## Description   - Phrase", "GameFontHighlightSmall")
    help:SetPoint("TOPLEFT", 24, -44)

    local box = ns.CreateBackdropFrame("Frame", nil, win)
    box:SetPoint("TOPLEFT", 20, -62)
    box:SetPoint("BOTTOMRIGHT", -20, 96)

    local scroll = CreateFrame("ScrollFrame", "QuipsForeverImportExportScroll", box, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -8)
    scroll:SetPoint("BOTTOMRIGHT", -28, 8)

    local edit = CreateFrame("EditBox", "QuipsForeverImportExportEdit", scroll)
    edit:SetMultiLine(true)
    edit:SetAutoFocus(false)
    edit:SetFontObject(ChatFontNormal)
    edit:SetWidth(500)
    edit:SetHeight(300)
    edit:SetMaxLetters(999999)
    edit:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
    if ScrollingEdit_OnCursorChanged then
        edit:SetScript("OnCursorChanged", ScrollingEdit_OnCursorChanged)
        edit:SetScript("OnUpdate", function(self, elapsed) ScrollingEdit_OnUpdate(self, elapsed, scroll) end)
        edit:SetScript("OnTextChanged", function(self, user) ScrollingEdit_OnTextChanged(self, scroll) end)
    end
    scroll:SetScrollChild(edit)
    scroll:SetScript("OnSizeChanged", function(self, w) edit:SetWidth(math.max(50, w)) end)
    box:EnableMouse(true)
    box:SetScript("OnMouseDown", function() edit:SetFocus() end)
    win.edit = edit

    local status = win:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    status:SetPoint("TOPLEFT", box, "BOTTOMLEFT", 4, -6)
    status:SetPoint("TOPRIGHT", box, "BOTTOMRIGHT", -4, -6)
    status:SetJustifyH("LEFT")
    status:SetJustifyV("TOP")
    status:SetHeight(44)
    win.status = status

    local bExport = ns.MakeButton(win, "Export", 100, 24, DoExport)
    bExport:SetPoint("BOTTOMLEFT", 20, 20)
    local bImport = ns.MakeButton(win, "Import (replace)", 130, 24, function() DoImport(false) end)
    bImport:SetPoint("LEFT", bExport, "RIGHT", 8, 0)
    local bMerge = ns.MakeButton(win, "Merge", 100, 24, function() DoImport(true) end)
    bMerge:SetPoint("LEFT", bImport, "RIGHT", 8, 0)
    local bClear = ns.MakeButton(win, "Clear", 80, 24, function()
        edit:SetText("")
        edit:SetFocus()
        SetStatus("")
    end)
    bClear:SetPoint("LEFT", bMerge, "RIGHT", 8, 0)
    local bClose = ns.MakeButton(win, "Close", 80, 24, function() win:Hide() end)
    bClose:SetPoint("BOTTOMRIGHT", -20, 20)
end

function ns.ShowImportExport()
    if not win then CreateWindow() end
    win:Show()
    win:Raise()
    SetStatus("Export copies your phrasebook out. Paste text in, then Import (replace) or Merge.")
end
